<template>
    <div id="vue-frontend-app">

    </div>
</template>

<script>
export default {
    name: 'App'
}
</script>

<style>

</style>
