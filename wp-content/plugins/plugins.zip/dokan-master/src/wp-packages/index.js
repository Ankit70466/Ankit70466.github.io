import { createHooks } from '@wordpress/hooks';

dokan.wpPackages = {
    hooks: createHooks()
};