<template>
    <div id="vue-backend-app">
        <router-view />
        <notifications position="bottom right"/>
    </div>
</template>

<script>
export default {
    name: 'App'
};
</script>

<style>

</style>
