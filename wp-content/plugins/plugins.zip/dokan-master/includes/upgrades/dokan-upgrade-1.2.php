<?php

dokan_generate_sync_table();